package pkgGame;

import org.apache.commons.lang.ArrayUtils;

public class Test {
    public static void main(String args[]) {
        int[] array = {0, 5, 6, 0, 0, 2, 5};

        // this loop is to remove all zeros
        while(ArrayUtils.contains(array, 0))
            array = ArrayUtils.removeElement(array, 0);

        // this loop will print the array elemnents
        for(int i : array)
            System.out.println(i);

    }
}
