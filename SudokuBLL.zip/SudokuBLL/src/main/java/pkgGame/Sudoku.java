package pkgGame;

import java.util.Arrays;

import pkgHelper.LatinSquare;


public class Sudoku extends LatinSquare{

	public Sudoku() {
		super();
	}
	
	public Sudoku(int[][] latinSquare) {
		super(latinSquare);
	}

	protected int[][] getPuzzle() {
		return super.getLatinSquare();
	}
	
	private static int[][] puzzle;
	
	public void Puzzle(int[][] puzzle) {
		this.puzzle = puzzle;
	}
	
	public int[] getRegion(int iRow, int iCol) throws Exception {
		int iSize = puzzle.length;
		int iSizeSqrt = (int) Math.sqrt(iSize);
		
		int i = (iCol / iSizeSqrt) + ((iRow / iSizeSqrt) * iSizeSqrt);
		
		return getRegion(i);
	}
	
	public int[] getRegion(int r) throws Exception {
		
		int[] myRegion = new int [puzzle.length];
		int idx = 0;
		int iSize = puzzle.length;
		int iSizeSqrt = (int) Math.sqrt(iSize);
		
		if ((r+1) > iSize)
			throw new Exception("Bad Region Call");
		
		for (int iRow = (r / iSizeSqrt) * iSizeSqrt; iRow < ((r / iSizeSqrt) * iSizeSqrt); iRow++) {
			for (int iCol = (r % iSizeSqrt) * iSizeSqrt; iCol < ((r % iSizeSqrt) * iSizeSqrt) + iSizeSqrt; iCol++) {
				myRegion[idx++] = puzzle[iRow][iCol];
			}
		}
		return myRegion;
	}

	@Override
	protected boolean hasDuplicates() throws Exception {
		
		super.hasDuplicates();
		
		for (int k = 0; k < this.getLatinSquare().length; k++) {
			if (hasDuplicates(getRegion(k)))
				return true;
		}
		
		return false;
	}
	
	protected boolean isSudoku() throws Exception {
		
		boolean isSudoku = true;
		
		if (!super.isLatinSquare()) {
			return false;
		}
		
		for (int i = 0; i < puzzle.length; i++) {
			if (hasDuplicates(getRegion(i)))
				return false;
		}
		for (int i = 1; i < puzzle.length; i++) {
			if (!hasAllValues(getRegion(0), getRegion(i))) {
				return false;
				}
			}
		return isSudoku;
		}
	
	protected boolean isPartialSudoku() {
		return false;
	}
	
	protected boolean isValueValid(int iValue, int Col, int Row) {
		return false;
	}
}
